# Build FileForge using only your Android phone

You can build the APK in GitHub Actions without installing Android Studio.

1. Open github.com in Chrome and sign in or create a free GitHub account.
2. Create a new repository called `FileForge`. Public or private is fine.
3. Extract the project ZIP using your phone's Files app.
4. Upload all the extracted files and folders to the repository, making sure the hidden `.github` folder is included. The workflow is already provided.
5. Open the **Actions** tab, select **Build FileForge APK**, and tap **Run workflow**.
6. When it finishes, open the run, scroll to **Artifacts**, and download `FileForge-debug-apk`.
7. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install it. Android may ask you to allow Chrome or Files to install unknown apps.

## Important
The first version is a starter build. It does not yet include duplicate detection, ZIP tools, batch rename, or full folder navigation. Those can be added after the first APK is running. The app is intended for personal sideloading; broad file access is a sensitive Android permission and should only be granted if you are comfortable with it.
