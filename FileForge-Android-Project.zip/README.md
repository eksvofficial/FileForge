# FileForge Android starter

A native Kotlin + Jetpack Compose Android app.

## Current working features
- Internal storage capacity overview.
- Android all-files access permission flow.
- Scan shared storage for files at least 100 MB.
- Basic shared-folder overview.

## Build
This project is configured for Android Gradle Plugin 8.7.3, Gradle 8.9 and JDK 17.
See BUILD_ON_PHONE.md for a phone-only cloud build route.

Note: Android reports device-wide internal storage capacity, which can include app/system storage that this app cannot browse. The scanner only reports files it can access in shared storage.
