package com.fileforge.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.util.Locale

private val Bg = Color(0xFF0D0D12)
private val Panel = Color(0xFF191922)
private val Purple = Color(0xFF9B7BFF)
private val Muted = Color(0xFF9A98A8)
private val White = Color(0xFFF5F3FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FileForgeApp(
            hasAccess = { Environment.isExternalStorageManager() },
            requestAccess = {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        ) }
    }
}

data class LargeFile(val file: File, val bytes: Long)

@Composable
fun FileForgeApp(hasAccess: () -> Boolean, requestAccess: () -> Unit) {
    var access by remember { mutableStateOf(hasAccess()) }
    var tab by remember { mutableStateOf("Overview") }
    var largeFiles by remember { mutableStateOf<List<LargeFile>>(emptyList()) }
    var scanning by remember { mutableStateOf(false) }
    val stat = remember { StatFs(Environment.getExternalStorageDirectory().path) }
    val total = stat.totalBytes
    val free = stat.availableBytes
    val used = (total - free).coerceAtLeast(0)
    val usedFraction = if (total > 0) used.toFloat() / total else 0f

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Purple,
            onBackground = White, onSurface = White
        )
    ) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Overview", "Large files", "Browse").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = {
                            Icon(
                                when (item) {
                                    "Overview" -> Icons.Default.Dashboard
                                    "Large files" -> Icons.Default.FolderOpen
                                    else -> Icons.Default.Folder
                                }, contentDescription = item
                            )
                        },
                        label = { Text(item, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Purple, selectedTextColor = Purple,
                            indicatorColor = Purple.copy(alpha = .16f),
                            unselectedIconColor = Muted, unselectedTextColor = Muted
                        )
                    )
                }
            }
        }) { padding ->
            Column(
                Modifier.fillMaxSize().background(Bg).padding(padding).padding(horizontal = 20.dp)
            ) {
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).background(Purple, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Folder, null, tint = Color.White)
                    }
                    Spacer(Modifier.width(11.dp))
                    Column {
                        Text("FILEFORGE", fontSize = 19.sp, fontWeight = FontWeight.Black, color = White)
                        Text("YOUR STORAGE, UNDER CONTROL", fontSize = 9.sp, color = Muted, letterSpacing = 1.sp)
                    }
                }
                Spacer(Modifier.height(24.dp))

                when (tab) {
                    "Overview" -> {
                        Text("Storage overview", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(5.dp))
                        Text("A clearer view of your device.", color = Muted)
                        Spacer(Modifier.height(20.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Panel),
                            shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.padding(20.dp)) {
                                Text("INTERNAL STORAGE", color = Muted, fontSize = 11.sp, letterSpacing = 1.sp)
                                Spacer(Modifier.height(12.dp))
                                Text(formatBytes(used), fontSize = 32.sp, fontWeight = FontWeight.Bold)
                                Text("of ${formatBytes(total)} used", color = Muted)
                                Spacer(Modifier.height(18.dp))
                                LinearProgressIndicator(
                                    progress = { usedFraction.coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth().height(10.dp),
                                    color = Purple, trackColor = Color(0xFF34313F)
                                )
                                Spacer(Modifier.height(16.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    StorageStat("USED", formatBytes(used), Purple)
                                    StorageStat("AVAILABLE", formatBytes(free), Color(0xFF55D6A3))
                                }
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        Text("Quick tools", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        ToolRow("Find large files", "See what's taking up space", Icons.Default.Search) { tab = "Large files" }
                        ToolRow("Browse storage", "Explore folders and files", Icons.Default.Folder) { tab = "Browse" }
                        Spacer(Modifier.height(16.dp))
                        if (!access) {
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF302743)),
                                shape = RoundedCornerShape(16.dp)) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("Storage access needed", fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(5.dp))
                                    Text("Allow FileForge to browse files and scan for large items. You can change this permission in Android settings.",
                                        color = Muted, fontSize = 13.sp)
                                    Spacer(Modifier.height(12.dp))
                                    Button(onClick = requestAccess, colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                                        Text("Grant access")
                                    }
                                }
                            }
                        }
                    }
                    "Large files" -> {
                        Text("Large files", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("Find files larger than 100 MB.", color = Muted)
                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = {
                                access = hasAccess()
                                if (access) {
                                    scanning = true
                                    largeFiles = emptyList()
                                }
                            },
                            enabled = !scanning,
                            colors = ButtonDefaults.buttonColors(containerColor = Purple)
                        ) { Text(if (scanning) "Scanning…" else "Scan device") }
                        if (!access) {
                            Spacer(Modifier.height(12.dp))
                            Text("Grant storage access from the Overview tab to scan.", color = Muted)
                        }
                        if (scanning) {
                            LaunchedEffect(scanning) {
                                largeFiles = withContext(Dispatchers.IO) { scanLargeFiles() }
                                scanning = false
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        if (!scanning && largeFiles.isNotEmpty()) {
                            Text("${largeFiles.size} large files found", color = Muted)
                        } else if (!scanning && access && largeFiles.isEmpty()) {
                            Text("Tap Scan device to begin.", color = Muted)
                        }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(largeFiles) { item ->
                                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                                    Column(Modifier.padding(13.dp)) {
                                        Text(item.file.name, fontWeight = FontWeight.SemiBold)
                                        Text(formatBytes(item.bytes) + "  •  " + item.file.parent, color = Muted, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        Text("Browse storage", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("Your main shared folders.", color = Muted)
                        Spacer(Modifier.height(16.dp))
                        if (!access) {
                            Text("Grant storage access from the Overview tab first.", color = Muted)
                        } else {
                            val dirs = listOf("Download", "Documents", "Pictures", "Movies", "Music", "DCIM")
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(dirs) { name ->
                                    val folder = File(Environment.getExternalStorageDirectory(), name)
                                    ToolRow(name, if (folder.exists()) "${folder.listFiles()?.size ?: 0} items" else "Folder not found",
                                        Icons.Default.Folder) { }
                                }
                            }
                            Text("Folder browsing is being expanded in the next version.", color = Muted, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}

@Composable
fun StorageStat(label: String, value: String, color: Color) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).background(color, RoundedCornerShape(50)))
            Spacer(Modifier.width(6.dp))
            Text(label, color = Muted, fontSize = 10.sp)
        }
        Text(value, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}

@Composable
fun ToolRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Purple, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

fun scanLargeFiles(): List<LargeFile> {
    val root = Environment.getExternalStorageDirectory()
    val found = mutableListOf<LargeFile>()
    val stack = ArrayDeque<File>()
    stack.add(root)
    var visited = 0
    while (stack.isNotEmpty() && visited < 12000) {
        val current = stack.removeLast()
        visited++
        try {
            current.listFiles()?.forEach { f ->
                if (f.isDirectory) {
                    if (!f.name.startsWith(".")) stack.add(f)
                } else if (f.isFile && f.length() >= 100L * 1024 * 1024) {
                    found.add(LargeFile(f, f.length()))
                }
            }
        } catch (_: SecurityException) { }
    }
    return found.sortedByDescending { it.bytes }.take(100)
}

fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var index = -1
    do { value /= 1024.0; index++ } while (value >= 1024 && index < units.lastIndex)
    return String.format(Locale.UK, "%.1f %s", value, units[index])
}
